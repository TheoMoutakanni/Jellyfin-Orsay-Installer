using Avalonia.Controls;

namespace Jellyfin.Orsay.Installer.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}